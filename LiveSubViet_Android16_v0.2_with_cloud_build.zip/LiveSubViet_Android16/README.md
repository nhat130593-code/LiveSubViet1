# LiveSub Việt 0.2.0 — Android 16 development source

## Target
Vivo / Android 16, minSdk 29, targetSdk 35, Kotlin + Android Studio.

## Included
- User-approved MediaProjection screen capture.
- Floating overlay window that can be dragged.
- OCR using Google ML Kit Text Recognition, throttled to about one frame per 1.2 seconds.
- OCR crop limited to the bottom 42% of the screen.
- Automatic language identification with ML Kit.
- Online translation to Vietnamese through MyMemory public endpoint.

## Build
1. Install Android Studio and Android SDK 35.
2. Extract this ZIP and open the project folder in Android Studio.
3. Wait for Gradle Sync.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the debug APK on the Vivo phone.
6. Grant overlay permission, tap Start, and approve Android's screen-sharing prompt.

## Important limitations
- This is development source, not a tested or signed release APK. It has not been compiled or tested on a Vivo handset in this environment.
- Online translation uses a public MyMemory endpoint without a private API key. Public quotas, uptime and privacy terms may change. Subtitle text is sent to a third party. Do not use this prototype for sensitive content.
- Replace the public translation endpoint with a production translation provider and a secure backend before public release; never embed private API keys in an APK.
- The current 0.2.0 prototype performs OCR + translation. Speech recognition from movie audio is not implemented yet, so the user's requested OCR + speech “both” mode is not complete.
- Some apps protect video with DRM / secure surfaces and may return black frames or block screen capture. No app can guarantee overlay OCR on every streaming service.
- Language mapping is a starter list; unknown language IDs fall back to English.
- Test rotation, battery use, background restrictions and overlay behavior on the exact Vivo model. Funtouch OS may require allowing background activity / unrestricted battery use.


## Build APK in the cloud using only a phone
This project includes `.github/workflows/build-apk.yml`.
1. Create a GitHub repository and upload the extracted project files (not the ZIP itself).
2. Ensure the workflow file is uploaded at exactly `.github/workflows/build-apk.yml`.
3. Open the repository's Actions tab and run `Build LiveSub Viet APK` with `Run workflow`, or push to `main`.
4. Open the completed run and download the `LiveSubViet-debug-apk` artifact. Extract the downloaded artifact ZIP to obtain the APK.
5. Install the debug APK on your Android device after reviewing Android's install-from-this-source prompt.

The workflow uses a GitHub-hosted Ubuntu runner, JDK 17, Gradle 8.9, and uploads the debug APK as an artifact. This follows the Gradle/GitHub Actions workflow pattern. It does not create a signed Play Store release.
