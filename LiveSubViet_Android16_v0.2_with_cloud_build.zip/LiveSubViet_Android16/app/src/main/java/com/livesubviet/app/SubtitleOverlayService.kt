package com.livesubviet.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

class SubtitleOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var label: TextView? = null
    private lateinit var params: WindowManager.LayoutParams
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = TextView(this).apply {
            text = "LiveSub Việt • Đang chờ phụ đề…"; textSize = 18f
            setTextColor(Color.WHITE); setBackgroundColor(0xD9000000.toInt())
            setPadding(24, 16, 24, 16); gravity = Gravity.CENTER
            setShadowLayer(3f, 1f, 1f, Color.BLACK)
        }
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = 100 }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=params.x; startY=params.y; true }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX-downX).toInt()
                    params.y = startY - (e.rawY-downY).toInt()
                    wm.updateViewLayout(view, params); true
                }
                else -> true
            }
        }
        wm.addView(view, params); label = view
        SubtitleBus.listener = { value -> view.post { view.text = value } }
    }
    override fun onDestroy() {
        SubtitleBus.listener = null
        label?.let { if (it.isAttachedToWindow) wm.removeView(it) }
        label = null; super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
object SubtitleBus {
    @Volatile var listener: ((String) -> Unit)? = null
    fun publish(text: String) { listener?.invoke(text) }
}
