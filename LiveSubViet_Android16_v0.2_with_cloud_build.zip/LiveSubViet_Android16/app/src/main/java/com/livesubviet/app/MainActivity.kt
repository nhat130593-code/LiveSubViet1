package com.livesubviet.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val captureRequest = 1001
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val title = TextView(this).apply {
            text = "LiveSub Việt\n\nPhụ đề nổi và dịch trực tuyến"
            textSize = 23f; setTextColor(0xFFFFFFFF.toInt()); setPadding(24, 34, 24, 12)
        }
        val info = TextView(this).apply {
            text = "1. Cấp quyền hiển thị nổi.\n2. Bắt đầu chia sẻ màn hình.\n3. Mở ứng dụng xem phim.\n\nLưu ý: nội dung phụ đề được gửi đến dịch vụ trực tuyến để dịch."
            textSize = 15f; setTextColor(0xFFCFD8DC.toInt()); setPadding(24, 12, 24, 20)
        }
        val overlay = Button(this).apply {
            text = "Cấp quyền hiển thị nổi"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity))
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                else toast("Đã có quyền hiển thị nổi.")
            }
        }
        val start = Button(this).apply { text = "Bắt đầu đọc và dịch"; setOnClickListener { beginCapture() } }
        val stop = Button(this).apply {
            text = "Dừng LiveSub Việt"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                stopService(Intent(this@MainActivity, SubtitleOverlayService::class.java))
                toast("Đã gửi lệnh dừng.")
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 18, 20, 20); setBackgroundColor(0xFF101418.toInt())
            addView(title); addView(info); addView(overlay); addView(start); addView(stop)
        })
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1002)
    }
    private fun beginCapture() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Vui lòng cấp quyền hiển thị nổi trước.")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
    }
    @Deprecated("Kept for starter compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                startService(Intent(this, SubtitleOverlayService::class.java))
                val svc = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                }
                ContextCompat.startForegroundService(this, svc)
                toast("LiveSub Việt đã bắt đầu.")
            } else toast("Bạn chưa cho phép chia sẻ màn hình.")
        }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
