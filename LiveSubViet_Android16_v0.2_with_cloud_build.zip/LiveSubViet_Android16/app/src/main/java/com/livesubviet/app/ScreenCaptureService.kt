package com.livesubviet.app

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.languageid.LanguageIdentification
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "livesub_capture"
    }
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var worker: Handler? = null
    private val ocr = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val languageId = LanguageIdentification.getClient()
    private val executor = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private var lastText = ""
    private var lastFrame = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(7, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(7, notification())

        val result = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (result != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }

        val thread = HandlerThread("LiveSubOCR").apply { start() }
        worker = Handler(thread.looper)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        reader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(result, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, worker)
        virtualDisplay = projection?.createVirtualDisplay(
            "LiveSubScreen", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, worker
        )
        reader?.setOnImageAvailableListener({ source ->
            val now = System.currentTimeMillis()
            if (now - lastFrame < 1200L || busy.get()) {
                source.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            lastFrame = now
            source.acquireLatestImage()?.let { processFrame(it) }
        }, worker)
        return START_NOT_STICKY
    }

    private fun processFrame(image: Image) {
        var full: Bitmap? = null
        try {
            full = imageToBitmap(image) ?: return
            val top = (full.height * 0.58f).toInt()
            val crop = Bitmap.createBitmap(full, 0, top, full.width, full.height - top)
            full.recycle(); full = null
            ocr.process(InputImage.fromBitmap(crop, 0))
                .addOnSuccessListener { result ->
                    val text = result.text.trim().replace(Regex("\\s+"), " ")
                    if (text.length >= 2 && text != lastText && busy.compareAndSet(false, true)) {
                        lastText = text
                        identifyAndTranslate(text)
                    }
                }
                .addOnCompleteListener { crop.recycle() }
        } catch (_: Exception) {
            full?.recycle()
        } finally { image.close() }
    }

    private fun identifyAndTranslate(text: String) {
        languageId.identifyLanguage(text)
            .addOnSuccessListener { lang ->
                translateAsync(text, if (lang == "und") "en" else lang)
            }
            .addOnFailureListener { translateAsync(text, "en") }
    }

    private fun translateAsync(text: String, language: String) {
        executor.execute {
            try { SubtitleBus.publish(TranslationClient.translateToVietnamese(text, language)) }
            catch (_: Exception) { SubtitleBus.publish("Không dịch được • Kiểm tra Internet") }
            finally { busy.set(false) }
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888)
        buffer.rewind(); padded.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "LiveSub Việt đang chạy", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun notification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LiveSub Việt đang hoạt động")
            .setContentText("Đang nhận diện và dịch phụ đề")
            .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build()

    override fun onDestroy() {
        virtualDisplay?.release(); reader?.close(); projection?.stop()
        ocr.close(); languageId.close(); executor.shutdown()
        worker?.looper?.quitSafely(); super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
