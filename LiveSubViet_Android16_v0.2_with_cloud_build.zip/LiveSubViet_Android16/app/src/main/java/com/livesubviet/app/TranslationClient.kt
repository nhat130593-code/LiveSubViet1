package com.livesubviet.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

// Prototype online translator. Subtitle text is sent to MyMemory's public service.
object TranslationClient {
    fun translateToVietnamese(text: String, sourceLanguage: String): String {
        val source = normalize(sourceLanguage)
        val q = URLEncoder.encode(text, Charsets.UTF_8.name())
        val pair = URLEncoder.encode("$source|vi", Charsets.UTF_8.name())
        val connection = (URL("https://api.mymemory.translated.net/get?q=$q&langpair=$pair")
            .openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 8000; readTimeout = 10000
            setRequestProperty("Accept", "application/json")
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            val translated = JSONObject(body).optJSONObject("responseData")?.optString("translatedText")
            if (translated.isNullOrBlank()) throw IllegalStateException("Dịch vụ trả về lỗi HTTP $code")
            return translated
        } finally { connection.disconnect() }
    }
    private fun normalize(code: String): String {
        val base = code.lowercase().substringBefore('-')
        return if (base in setOf("zh","ja","ko","en","fr","de","es","it","pt","ru","th","id","ms","ar","hi","nl","tr","pl","uk")) base else "en"
    }
}
